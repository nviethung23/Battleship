// Game screen functions (continuation from game.js)

// Note: myCharacterId and opponentCharacterId are already declared in characterSelection.js
// Don't redeclare them here to avoid "already declared" error

let gamePlayers = { player1: null, player2: null };

function startGameScreen(data) {
    console.log('=== startGameScreen called ===');
    console.log('Game data:', data);
    console.log('gameState.myBoard:', gameState.myBoard);
    console.log('gameState.myShips:', gameState.myShips);
    
    showGameScreen();
    gameState.gameStarted = true;
    gameState.currentTurn = data.currentTurn;
    gameState.isMyTurn = data.currentTurn === currentUserId;

    // Set player names
    const gamePlayer1El = document.getElementById('gamePlayer1');
    const gamePlayer2El = document.getElementById('gamePlayer2');
    
    if (gamePlayer1El) {
        gamePlayer1El.textContent = data.player1.username;
    }
    if (gamePlayer2El) {
        gamePlayer2El.textContent = data.player2.username;
    }
    
    // Save character IDs and player info
    if (data.player1.userId === currentUserId) {
        myCharacterId = data.player1.characterId || 'character1';
        opponentCharacterId = data.player2.characterId || 'character1';
        gamePlayers.player1 = data.player1;
        gamePlayers.player2 = data.player2;
    } else {
        myCharacterId = data.player2.characterId || 'character1';
        opponentCharacterId = data.player1.characterId || 'character1';
        gamePlayers.player1 = data.player1;
        gamePlayers.player2 = data.player2;
    }

    // Update character banners (removed - banners deleted from UI)
    // updateCharacterBanners();

    // Render dynamic layout
    try {
        console.log('Calling renderDynamicBoardLayout...');
        renderDynamicBoardLayout();
        console.log('✅ renderDynamicBoardLayout completed');
    } catch (error) {
        console.error('❌ Error in renderDynamicBoardLayout:', error);
    }

    // Show transition
    showTurnTransition(gameState.isMyTurn);

    showNotification('Trận đấu bắt đầu!', 'success');
}

// Show transition "YOUR TURN" / "ENEMY'S TURN"
function showTurnTransition(isMyTurn) {
    const transition = document.getElementById('turnTransition');
    const title = document.getElementById('transitionTitle');
    
    title.textContent = isMyTurn ? 'YOUR TURN' : "ENEMY'S TURN";
    title.style.color = isMyTurn ? '#4CAF50' : '#FF6B6B';
    
    transition.style.display = 'flex';
    transition.classList.remove('fade-out');
    
    // Fade out after 2 seconds
    setTimeout(() => {
        transition.classList.add('fade-out');
        setTimeout(() => {
            transition.style.display = 'none';
        }, 500);
    }, 2000);
}

// Render dynamic board layout based on turn
function renderDynamicBoardLayout() {
    console.log('=== renderDynamicBoardLayout called ===');
    console.log('gameState.isMyTurn:', gameState.isMyTurn);
    console.log('gameState.currentTurn:', gameState.currentTurn);
    console.log('currentUserId:', currentUserId);
    
    const leftWrapper = document.getElementById('leftBoardWrapper');
    const rightWrapper = document.getElementById('rightBoardWrapper');
    const leftTitle = document.getElementById('leftBoardTitle');
    const rightTitle = document.getElementById('rightBoardTitle');
    const leftHeader = document.getElementById('leftBoardHeader');
    const rightHeader = document.getElementById('rightBoardHeader');
    const leftInfo = document.getElementById('leftBoardInfo');
    const rightInfo = document.getElementById('rightBoardInfo');
    const leftSide = document.querySelector('.left-side');
    const rightSide = document.querySelector('.right-side');
    
    console.log('DOM elements found:', {
        leftWrapper: !!leftWrapper,
        rightWrapper: !!rightWrapper,
        leftSide: !!leftSide,
        rightSide: !!rightSide
    });
    
    if (!leftWrapper || !rightWrapper || !leftSide || !rightSide) {
        console.error('❌ Required DOM elements not found!');
        return;
    }
    
    // Clear existing
    leftWrapper.innerHTML = '';
    rightWrapper.innerHTML = '';
    leftInfo.innerHTML = '';
    rightInfo.innerHTML = '';
    
    console.log('Cleared existing content');
    
    if (gameState.isMyTurn) {
        console.log('→ Rendering YOUR TURN layout');
        // YOUR TURN Layout
        // Left: Small fleet
        leftTitle.textContent = 'YOUR FLEET';
        leftHeader.className = 'board-header fleet-header';
        leftSide.classList.remove('large-board');
        leftSide.classList.add('small-board');
        
        const yourBoardSmall = createBoard('yourBoardSmall', 'board-small', false);
        console.log('Created yourBoardSmall:', yourBoardSmall);
        leftWrapper.appendChild(yourBoardSmall);
        console.log('Appended to leftWrapper, calling renderYourFleet...');
        renderYourFleet(yourBoardSmall);
        
        // Ships status
        console.log('Rendering ships status...');
        leftInfo.innerHTML = '<h4>Tàu của bạn:</h4>' + renderShipsStatusHTML();
        
        // Right: Large attack board
        rightTitle.textContent = 'YOUR TURN';
        rightHeader.className = 'board-header your-turn';
        rightSide.classList.remove('small-board');
        rightSide.classList.add('large-board');
        
        const enemyBoardLarge = createBoard('enemyBoardLarge', 'board-large', true);
        console.log('Created enemyBoardLarge:', enemyBoardLarge);
        rightWrapper.appendChild(enemyBoardLarge);
        console.log('Appended to rightWrapper, calling renderEnemyAttackBoard...');
        renderEnemyAttackBoard(enemyBoardLarge);
        
        // Attack log
        rightInfo.innerHTML = '<h4>Lịch sử tấn công:</h4><div id="attackLogContent"></div>';
        
    } else {
        console.log('→ Rendering ENEMY\'S TURN layout');
        // ENEMY'S TURN Layout
        // Left: Large your fleet (under attack)
        leftTitle.textContent = "ENEMY'S TURN";
        leftHeader.className = 'board-header enemy-turn';
        leftSide.classList.remove('small-board');
        leftSide.classList.add('large-board');
        
        const yourBoardLarge = createBoard('yourBoardLarge', 'board-large', false);
        leftWrapper.appendChild(yourBoardLarge);
        renderYourFleet(yourBoardLarge);
        
        // Ships status
        leftInfo.innerHTML = '<h4>Tàu của bạn:</h4>' + renderShipsStatusHTML();
        
        // Right: Small enemy fleet (your attacks)
        rightTitle.textContent = "ENEMY'S FLEET";
        rightHeader.className = 'board-header fleet-header';
        rightSide.classList.remove('large-board');
        rightSide.classList.add('small-board');
        
        const enemyBoardSmall = createBoard('enemyBoardSmall', 'board-small', false);
        rightWrapper.appendChild(enemyBoardSmall);
        renderEnemyFleetMini(enemyBoardSmall);
        
        // Attack log
        rightInfo.innerHTML = '<h4>Bạn đã bắn:</h4><div id="attackLogContent"></div>';
    }
    
    console.log('✅ renderDynamicBoardLayout completed');
    console.log('leftWrapper children:', leftWrapper.children.length);
    console.log('rightWrapper children:', rightWrapper.children.length);
}

// Create board element
function createBoard(id, sizeClass, isClickable) {
    const board = document.createElement('div');
    board.id = id;
    board.className = `board ${sizeClass}`;
    return board;
}

// Render your fleet board
function renderYourFleet(boardElement) {
    console.log('=== renderYourFleet called ===');
    console.log('boardElement:', boardElement);
    console.log('gameState.myBoard:', gameState.myBoard);
    console.log('GRID_SIZE:', typeof GRID_SIZE !== 'undefined' ? GRID_SIZE : 'UNDEFINED');
    
    if (!boardElement) {
        console.error('❌ boardElement is null!');
        return;
    }
    
    boardElement.innerHTML = '';
    
    // Check if myBoard exists
    if (!gameState.myBoard || !Array.isArray(gameState.myBoard)) {
        console.error('❌ gameState.myBoard is not initialized!');
        // Still render empty board for debugging
        const gridSize = typeof GRID_SIZE !== 'undefined' ? GRID_SIZE : 10;
        for (let row = 0; row < gridSize; row++) {
            for (let col = 0; col < gridSize; col++) {
                const cell = document.createElement('div');
                cell.className = 'cell';
                cell.dataset.row = row;
                cell.dataset.col = col;
                boardElement.appendChild(cell);
            }
        }
        console.log('✅ Rendered empty board with', gridSize * gridSize, 'cells');
        return;
    }
    
    const gridSize = gameState.myBoard.length;
    console.log('Rendering board with size:', gridSize);
    
    for (let row = 0; row < gridSize; row++) {
        for (let col = 0; col < gridSize; col++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.dataset.row = row;
            cell.dataset.col = col;

            if (gameState.myBoard[row] && gameState.myBoard[row][col]) {
                cell.classList.add('ship');
            }

            // Check if this cell was hit by enemy
            const wasHit = gameState.enemyAttacks.find(a => a.row === row && a.col === col);
            if (wasHit) {
                cell.classList.add(wasHit.hit ? 'hit' : 'miss');
            }

            boardElement.appendChild(cell);
        }
    }
    
    console.log('✅ Rendered YOUR fleet board with', gridSize * gridSize, 'cells');
}

// Render enemy attack board (large, clickable when your turn)
function renderEnemyAttackBoard(boardElement) {
    console.log('=== renderEnemyAttackBoard called ===');
    console.log('boardElement:', boardElement);
    
    if (!boardElement) {
        console.error('❌ boardElement is null!');
        return;
    }
    
    boardElement.innerHTML = '';
    
    let cellCount = 0;
    for (let row = 0; row < GRID_SIZE; row++) {
        for (let col = 0; col < GRID_SIZE; col++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.dataset.row = row;
            cell.dataset.col = col;

            // Check if we attacked this cell
            const wasAttacked = gameState.myAttacks.find(a => a.row === row && a.col === col);
            if (wasAttacked) {
                cell.classList.add(wasAttacked.hit ? 'hit' : 'miss');
            } else if (gameState.isMyTurn) {
                // Only clickable if it's our turn and not attacked
                cell.style.cursor = 'pointer';
                cell.addEventListener('click', () => {
                    attackCell(row, col);
                });
            }

            boardElement.appendChild(cell);
            cellCount++;
        }
    }
    
    console.log('✅ Rendered enemy attack board with', cellCount, 'cells');
}

// Render enemy fleet mini (small, show our attacks)
function renderEnemyFleetMini(boardElement) {
    boardElement.innerHTML = '';
    
    for (let row = 0; row < GRID_SIZE; row++) {
        for (let col = 0; col < GRID_SIZE; col++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.dataset.row = row;
            cell.dataset.col = col;

            // Show our attacks
            const wasAttacked = gameState.myAttacks.find(a => a.row === row && a.col === col);
            if (wasAttacked) {
                cell.classList.add(wasAttacked.hit ? 'hit' : 'miss');
            }

            boardElement.appendChild(cell);
        }
    }
}

// Render ships status HTML
function renderShipsStatusHTML() {
    console.log('=== renderShipsStatusHTML called ===');
    console.log('gameState.myShips:', gameState.myShips);
    
    if (!gameState.myShips || gameState.myShips.length === 0) {
        console.warn('⚠️ gameState.myShips is empty!');
        return '<div class="ships-status-list"><p>Không có tàu nào.</p></div>';
    }
    
    let html = '<div class="ships-status-list">';
    
    gameState.myShips.forEach(ship => {
        const hits = gameState.enemyAttacks.filter(a => {
            return a.hit && ship.cells.some(c => c.row === a.row && c.col === a.col);
        }).length;

        const isSunk = hits === ship.size;
        const statusClass = isSunk ? 'sunk' : '';
        
        html += `
            <div class="ship-status-item ${statusClass}">
                <span>${ship.name}</span>
                <span>${hits}/${ship.size} ${isSunk ? '💀' : '🚢'}</span>
            </div>
        `;
    });

    html += '</div>';
    console.log('✅ renderShipsStatusHTML completed');
    return html;
}

// renderShipsStatus đã thay bằng renderShipsStatusHTML

function attackCell(row, col) {
    if (!gameState.isMyTurn) {
        showNotification('Chưa đến lượt của bạn!', 'warning');
        return;
    }

    // Check if already attacked
    if (gameState.myAttacks.some(a => a.row === row && a.col === col)) {
        showNotification('Đã bắn ô này rồi!', 'warning');
        return;
    }

    sendAttack(row, col);
}

function handleAttackResult(data) {
    const isMyAttack = data.attackerId === currentUserId;
    console.log('💥 ATTACK_RESULT -', isMyAttack ? 'Tôi bắn' : 'Địch bắn', '| Hit:', data.hit, '| Attacker:', data.attacker);

    if (isMyAttack) {
        // My attack
        gameState.myAttacks.push({
            row: data.row,
            col: data.col,
            hit: data.hit
        });

        let message;
        if (data.hit) {
            if (data.sunk) {
                message = `Trúng và đánh chìm ${data.shipSunk}! 💥 Bắn tiếp!`;
            } else {
                message = 'Trúng mục tiêu! 🎯 Bắn tiếp!';
            }
        } else {
            message = 'Trượt! 💨 Lượt của đối thủ!';
        }
        showNotification(message, data.hit ? 'success' : 'info');

        addAttackLog(`Bạn bắn [${String.fromCharCode(65 + data.col)}${data.row + 1}]: ${message}`);
    } else {
        // Enemy attack
        gameState.enemyAttacks.push({
            row: data.row,
            col: data.col,
            hit: data.hit
        });

        let message;
        if (data.hit) {
            if (data.sunk) {
                message = `${data.attacker} đánh chìm ${data.shipSunk} của bạn! 💥 Họ được bắn tiếp!`;
            } else {
                message = `${data.attacker} trúng tàu của bạn! 🎯 Họ được bắn tiếp!`;
            }
        } else {
            message = `${data.attacker} bắn trượt! 💨 Đến lượt bạn!`;
        }
        showNotification(message, data.hit ? 'error' : 'info');

        addAttackLog(`${data.attacker} bắn [${String.fromCharCode(65 + data.col)}${data.row + 1}]: ${data.hit ? 'Trúng!' : 'Trượt!'}`);
    }

    // Re-render dynamic layout
    renderDynamicBoardLayout();
}

function updateTurn(data, showTransition = true) {
    gameState.currentTurn = data.currentTurn;
    gameState.isMyTurn = data.currentTurn === currentUserId;
    
    console.log('🎮 UPDATE_TURN - isMyTurn:', gameState.isMyTurn, '| showTransition:', showTransition);

    if (showTransition) {
        // Chuyển lượt → Show transition
        showTurnTransition(gameState.isMyTurn);
        
        // Re-render dynamic layout after transition
        setTimeout(() => {
            renderDynamicBoardLayout();
        }, 500);
    } else {
        // Bắn trúng, vẫn còn lượt → Chỉ re-render boards, KHÔNG show transition
        renderDynamicBoardLayout();
    }

    // Reset timer
    startTimer();
}

function startTimer() {
    if (gameState.timerInterval) {
        clearInterval(gameState.timerInterval);
    }

    let timeLeft = 60;
    const timerText = document.getElementById('timer');
    const timerContainer = document.querySelector('.timer-container');
    
    timerText.textContent = timeLeft;
    timerContainer.classList.remove('warning', 'danger');

    gameState.timerInterval = setInterval(() => {
        timeLeft--;
        timerText.textContent = timeLeft;

        if (timeLeft <= 10) {
            timerContainer.classList.remove('warning');
            timerContainer.classList.add('danger');
        } else if (timeLeft <= 20) {
            timerContainer.classList.add('warning');
        }

        if (timeLeft <= 0) {
            clearInterval(gameState.timerInterval);
        }
    }, 1000);
}

function addAttackLog(message) {
    const logContainer = document.getElementById('attackLog');
    const logItem = document.createElement('div');
    logItem.className = 'log-item';
    if (message.includes('Trúng') || message.includes('trúng')) {
        logItem.classList.add('hit');
    }
    logItem.textContent = message;
    logContainer.insertBefore(logItem, logContainer.firstChild);

    // Keep only last 10 logs
    while (logContainer.children.length > 10) {
        logContainer.removeChild(logContainer.lastChild);
    }
}

function showGameOver(data) {
    if (gameState.timerInterval) {
        clearInterval(gameState.timerInterval);
    }

    showGameOverScreen();

    const isWinner = data.winnerId === currentUserId;
    
    // Get character IDs
    const myCharId = data.winnerId === currentUserId ? data.winnerCharacterId : data.loserCharacterId;
    const opponentCharId = data.winnerId === currentUserId ? data.loserCharacterId : data.winnerCharacterId;
    
    // Title ở giữa phía trên
    const titleElement = document.getElementById('gameOverTitle');
    if (titleElement) {
        titleElement.textContent = isWinner ? 'Bạn đã thắng cuộc!' : 'Bạn đã thua cuộc!';
        titleElement.className = `game-over-title ${isWinner ? 'win' : 'lose'}`;
    }
    
    // Duration
    const duration = Math.floor(data.duration / 1000);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    const durationElement = document.getElementById('gameOverDuration');
    if (durationElement) {
        durationElement.textContent = `Thời gian: ${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // Left: My Character (luôn ở bên trái)
    const myChar = getCharacterById(myCharId);
    const myCharImg = document.getElementById('myCharacterResult');
    const myCharName = document.getElementById('myCharacterName');
    const myResultLabel = document.getElementById('myResultLabel');
    
    if (myCharImg && myChar) {
        // Hiển thị ảnh win hoặc lose
        myCharImg.src = isWinner ? getCharacterWinAvatar(myCharId) : getCharacterLoseAvatar(myCharId);
        myCharImg.alt = myChar.displayName;
    }
    
    if (myCharName && myChar) {
        myCharName.textContent = myChar.displayName;
    }
    
    if (myResultLabel) {
        myResultLabel.textContent = isWinner ? 'Thắng' : 'Thua';
        myResultLabel.className = `character-result-label ${isWinner ? 'win' : 'lose'}`;
    }
    
    // Right: Opponent Character
    const opponentChar = getCharacterById(opponentCharId);
    const opponentCharImg = document.getElementById('opponentCharacterResult');
    const opponentCharName = document.getElementById('opponentCharacterName');
    const opponentResultLabel = document.getElementById('opponentResultLabel');
    
    if (opponentCharImg && opponentChar) {
        // Hiển thị ảnh win hoặc lose (ngược lại với mình)
        opponentCharImg.src = isWinner ? getCharacterLoseAvatar(opponentCharId) : getCharacterWinAvatar(opponentCharId);
        opponentCharImg.alt = opponentChar.displayName;
    }
    
    if (opponentCharName && opponentChar) {
        opponentCharName.textContent = opponentChar.displayName;
    }
    
    if (opponentResultLabel) {
        opponentResultLabel.textContent = isWinner ? 'Thua' : 'Thắng';
        opponentResultLabel.className = `character-result-label ${isWinner ? 'lose' : 'win'}`;
    }

    showNotification(isWinner ? 'Chúc mừng bạn đã chiến thắng!' : 'Bạn đã thua cuộc!', isWinner ? 'success' : 'error');
}

// Update character banners in game screen
// Character banners removed from UI - function no longer needed
// function updateCharacterBanners() {
//     // Get character data
//     const myChar = getCharacterById(myCharacterId);
//     const opponentChar = getCharacterById(opponentCharacterId);
//     
//     // Update my character banner (left top)
//     const myCharName = document.getElementById('myCharacterName');
//     const myCharAvatar = document.getElementById('myCharacterAvatar');
//     const myCharStat = document.getElementById('myCharacterStat');
//     
//     if (myCharName && myChar) {
//         myCharName.textContent = currentUsername + "'s";
//     }
//     
//     if (myCharAvatar && myChar) {
//         myCharAvatar.src = getCharacterAvatar(myCharacterId, 'medium');
//         myCharAvatar.alt = myChar.displayName;
//     }
//     
//     if (myCharStat) {
//         // Calculate stat based on remaining ships or hits (example: 42)
//         // You can update this logic based on game state
//         myCharStat.textContent = '42';
//     }
//     
//     // Update opponent character banner (right bottom)
//     const opponentCharName = document.getElementById('opponentCharacterName');
//     const opponentCharAvatar = document.getElementById('opponentCharacterAvatar');
//     const opponentCharStat = document.getElementById('opponentCharacterStat');
//     
//     if (opponentCharName && opponentChar) {
//         // Get opponent username from game players
//         const opponentPlayer = gamePlayers.player1?.userId === currentUserId 
//             ? gamePlayers.player2 
//             : gamePlayers.player1;
//         opponentCharName.textContent = (opponentPlayer?.username || 'Opponent') + "'s";
//     }
//     
//     if (opponentCharAvatar && opponentChar) {
//         opponentCharAvatar.src = getCharacterAvatar(opponentCharacterId, 'medium');
//         opponentCharAvatar.alt = opponentChar.displayName;
//     }
//     
//     if (opponentCharStat) {
//         opponentCharStat.textContent = '42';
//     }
// }

