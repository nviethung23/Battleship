// WebRTC functionality for voice/video call

let localStream = null;
let remoteStream = null;
let peerConnection = null;
let isCallActive = false;
let isVideoEnabled = true;
let isAudioEnabled = true;

const configuration = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
    ]
};

document.addEventListener('DOMContentLoaded', () => {
    const startCallBtn = document.getElementById('startCallBtn');
    const endCallBtn = document.getElementById('endCallBtn');
    const toggleVideoBtn = document.getElementById('toggleVideoBtn');
    const toggleAudioBtn = document.getElementById('toggleAudioBtn');

    if (startCallBtn) {
        startCallBtn.addEventListener('click', () => {
            startCall();
        });
    }

    if (endCallBtn) {
        endCallBtn.addEventListener('click', () => {
            endCall();
        });
    }

    if (toggleVideoBtn) {
        toggleVideoBtn.addEventListener('click', () => {
            toggleVideo();
        });
    }

    if (toggleAudioBtn) {
        toggleAudioBtn.addEventListener('click', () => {
            toggleAudio();
        });
    }
});

async function startCall() {
    if (!socket || !currentRoomId) {
        showNotification('Chưa trong phòng chơi', 'error');
        return;
    }

    try {
        // Get local media
        localStream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true
        });

        // Display local video
        const localVideo = document.getElementById('localVideo');
        localVideo.srcObject = localStream;

        // Create peer connection
        peerConnection = new RTCPeerConnection(configuration);

        // Add local stream to peer connection
        localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
        });

        // Handle ICE candidates
        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                socket.emit('webrtc_ice_candidate', {
                    roomId: currentRoomId,
                    candidate: event.candidate
                });
            }
        };

        // Handle remote stream
        peerConnection.ontrack = (event) => {
            remoteStream = event.streams[0];
            const remoteVideo = document.getElementById('remoteVideo');
            remoteVideo.srcObject = remoteStream;
        };

        // Create offer
        const offer = await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);

        // Send offer to peer
        socket.emit('webrtc_offer', {
            roomId: currentRoomId,
            offer: offer
        });

        // Also send call request notification
        socket.emit('call_request', {
            roomId: currentRoomId
        });

        isCallActive = true;
        updateCallButtons();

        showNotification('Đang gọi...', 'info');
    } catch (error) {
        console.error('Error starting call:', error);
        showNotification('Không thể bắt đầu cuộc gọi. Vui lòng kiểm tra camera/microphone.', 'error');
    }
}

async function handleWebRTCOffer(data) {
    try {
        // Get local media
        if (!localStream) {
            localStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });

            const localVideo = document.getElementById('localVideo');
            localVideo.srcObject = localStream;
        }

        // Create peer connection
        peerConnection = new RTCPeerConnection(configuration);

        // Add local stream
        localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
        });

        // Handle ICE candidates
        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                socket.emit('webrtc_ice_candidate', {
                    roomId: currentRoomId,
                    candidate: event.candidate
                });
            }
        };

        // Handle remote stream
        peerConnection.ontrack = (event) => {
            remoteStream = event.streams[0];
            const remoteVideo = document.getElementById('remoteVideo');
            remoteVideo.srcObject = remoteStream;
        };

        // Set remote description (offer)
        await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));

        // Create answer
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);

        // Send answer
        socket.emit('webrtc_answer', {
            roomId: currentRoomId,
            answer: answer
        });

        isCallActive = true;
        updateCallButtons();

        showNotification('Đã kết nối cuộc gọi', 'success');
    } catch (error) {
        console.error('Error handling offer:', error);
        showNotification('Lỗi khi nhận cuộc gọi', 'error');
    }
}

async function handleWebRTCAnswer(data) {
    try {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
        showNotification('Cuộc gọi đã được kết nối', 'success');
    } catch (error) {
        console.error('Error handling answer:', error);
    }
}

async function handleWebRTCIceCandidate(data) {
    try {
        if (peerConnection) {
            await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    } catch (error) {
        console.error('Error adding ICE candidate:', error);
    }
}

function handleCallRequest(data) {
    showNotification(`${data.from} đang gọi cho bạn...`, 'info');
    // Call will be automatically accepted when offer is received
}

function handleCallAccepted(data) {
    showNotification('Cuộc gọi được chấp nhận', 'success');
}

function handleCallRejected(data) {
    showNotification('Cuộc gọi bị từ chối', 'error');
    endCall();
}

function handleCallEnded(data) {
    showNotification('Cuộc gọi đã kết thúc', 'info');
    endCall();
}

function endCall() {
    // Stop local stream
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        localStream = null;
    }

    // Close peer connection
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
    }

    // Clear video elements
    const localVideo = document.getElementById('localVideo');
    const remoteVideo = document.getElementById('remoteVideo');
    if (localVideo) localVideo.srcObject = null;
    if (remoteVideo) remoteVideo.srcObject = null;

    // Notify peer
    if (socket && currentRoomId && isCallActive) {
        socket.emit('end_call', {
            roomId: currentRoomId
        });
    }

    isCallActive = false;
    updateCallButtons();
}

function toggleVideo() {
    if (!localStream) return;

    isVideoEnabled = !isVideoEnabled;
    localStream.getVideoTracks().forEach(track => {
        track.enabled = isVideoEnabled;
    });

    const btn = document.getElementById('toggleVideoBtn');
    btn.textContent = isVideoEnabled ? '📹' : '📹❌';
    btn.style.opacity = isVideoEnabled ? '1' : '0.5';
}

function toggleAudio() {
    if (!localStream) return;

    isAudioEnabled = !isAudioEnabled;
    localStream.getAudioTracks().forEach(track => {
        track.enabled = isAudioEnabled;
    });

    const btn = document.getElementById('toggleAudioBtn');
    btn.textContent = isAudioEnabled ? '🎤' : '🎤❌';
    btn.style.opacity = isAudioEnabled ? '1' : '0.5';
}

function updateCallButtons() {
    const startCallBtn = document.getElementById('startCallBtn');
    const endCallBtn = document.getElementById('endCallBtn');

    if (startCallBtn && endCallBtn) {
        if (isCallActive) {
            startCallBtn.style.display = 'none';
            endCallBtn.style.display = 'inline-block';
        } else {
            startCallBtn.style.display = 'inline-block';
            endCallBtn.style.display = 'none';
        }
    }
}

