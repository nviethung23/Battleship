/**
 * Lobby Page Logic
 * Handles waiting room: show players, ready button, leave button, timer
 * CRITICAL: Must preserve ready button logic that triggers deployment phase
 */

// Character data for UI preview (cosmetic only)
const LOBBY_CHARACTERS = [
    { id: 0, name: 'Captain Morgan', image: 'images/characters/character1/avatar-large.png' },
    { id: 1, name: 'Admiral Blake', image: 'images/characters/character2/avatar-large.png' },
    { id: 2, name: 'Commander Storm', image: 'images/characters/character3/avatar-large.png' }
];

let selectedCharacterIndex = 0;
let currentRoom = null;
let lobbyTimerInterval = null;
let isReady = false;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('[Lobby] Page loaded');

    // Check authentication
    if (!BattleshipState.isAuthenticated()) {
        console.error('[Lobby] Not authenticated, redirecting to login');
        window.location.href = '/';
        return;
    }

    // Check room code
    const roomCode = BattleshipState.getRoomCode();
    if (!roomCode) {
        console.error('[Lobby] No room code, redirecting to hub');
        window.location.href = '/hub';
        return;
    }

    console.log('[Lobby] Room code:', roomCode);

    // Initialize socket
    const socket = SocketShared.init((data) => {
        console.log('[Lobby] Socket connected:', data);
        // Join or rejoin room
        joinRoom(socket, roomCode);
    });

    if (!socket) return;

    // Setup event listeners
    setupEventListeners(socket);

    // Setup socket event handlers
    setupSocketHandlers(socket);

    // Initialize character selector (UI-only cosmetic)
    initCharacterSelector();

    // Display room code
    displayRoomCode(roomCode);

    console.log('[Lobby] Initialized successfully');
});

function joinRoom(socket, roomCode) {
    console.log('[Lobby] Requesting room info:', roomCode);
    
    // Request room info from server
    // Server will check if we're already in the room or need to join
    socket.emit('room:requestInfo', { roomCode });
}

function displayRoomCode(roomCode) {
    const roomCodeEl = document.getElementById('lobbyRoomCode');
    if (roomCodeEl) {
        roomCodeEl.textContent = roomCode;
    }
}

function setupEventListeners(socket) {
    // Leave button - CRITICAL: must emit leave event
    const leaveBtn = document.getElementById('btnLeaveRoom');
    if (leaveBtn) {
        leaveBtn.addEventListener('click', () => {
            console.log('[Lobby] Leave button clicked');
            handleLeave(socket);
        });
    }

    // Ready button - CRITICAL: must emit ready event to trigger deployment
    const readyBtn = document.getElementById('btnReady');
    if (readyBtn) {
        readyBtn.addEventListener('click', () => {
            console.log('[Lobby] Ready button clicked');
            handleReady(socket, readyBtn);
        });
    }

    // Character selector thumbnails (UI-only preview)
    const selectorThumbs = document.querySelectorAll('.selector-thumb');
    selectorThumbs.forEach((thumb, index) => {
        thumb.addEventListener('click', () => {
            selectedCharacterIndex = index;
            updateCharacterPreview();
            
            // Emit to server for realtime update
            socket.emit('lobby:characterChanged', {
                roomCode: BattleshipState.getRoomCode(),
                characterIndex: index
            });
        });
    });
}

function setupSocketHandlers(socket) {
    // Room joined successfully
    socket.on('room:joined', (data) => {
        console.log('[Lobby] Room joined:', data);
        currentRoom = data.room;
        updateLobbyUI(data.room);
    });

    // Room state updated
    socket.on('room:updated', (data) => {
        console.log('[Lobby] Room updated:', data);
        currentRoom = data.room;
        updateLobbyUI(data.room);
    });

    // Player joined
    socket.on('room:playerJoined', (data) => {
        console.log('[Lobby] Player joined:', data);
        currentRoom = data.room;
        updateLobbyUI(data.room);
        SocketShared.showNotification('Đối thủ đã tham gia!', 'success');
    });

    // Player ready
    socket.on('lobby:playerReady', (data) => {
        console.log('[Lobby] Player ready:', data);
        updatePlayerReadyStatus(data);
    });

    // Both players ready - game starts
    socket.on('lobby:bothReady', (data) => {
        console.log('[Lobby] Both players ready, starting game:', data);
        SocketShared.showNotification('Cả 2 người chơi đã sẵn sàng! Bắt đầu...', 'success');
        
        // Stop timer
        stopLobbyTimer();
        
        // Redirect to game page
        setTimeout(() => {
            window.location.href = '/game';
        }, 1500);
    });
    
    // Character changed (opponent changed character)
    socket.on('lobby:opponentCharacterChanged', (data) => {
        console.log('[Lobby] Opponent changed character:', data);
        const { characterIndex } = data;
        
        // Update opponent's character image
        const player2Img = document.getElementById('lobbyCharacter2');
        if (player2Img && LOBBY_CHARACTERS[characterIndex]) {
            player2Img.src = LOBBY_CHARACTERS[characterIndex].image;
        }
    });

    // Player left
    socket.on('room:playerLeft', (data) => {
        console.log('[Lobby] Player left:', data);
        if (data.leftUserId !== BattleshipState.getUserId()) {
            SocketShared.showNotification('Đối thủ đã rời phòng', 'warning');
            currentRoom = data.room;
            updateLobbyUI(data.room);
        }
    });

    // Room disbanded
    socket.on('room:disbanded', (data) => {
        console.log('[Lobby] Room disbanded:', data);
        SocketShared.showNotification('Phòng đã bị đóng', 'warning');
        BattleshipState.clearRoomState();
        setTimeout(() => {
            window.location.href = '/hub';
        }, 1500);
    });

    // Error handling
    socket.on('room:error', (data) => {
        console.error('[Lobby] Room error:', data);
        SocketShared.showNotification(data.message || 'Có lỗi xảy ra', 'error');
        
        // If room not found, redirect to hub
        if (data.code === 'ROOM_NOT_FOUND') {
            BattleshipState.clearRoomState();
            setTimeout(() => {
                window.location.href = '/hub';
            }, 2000);
        }
    });
}

function updateLobbyUI(room) {
    console.log('[Lobby] Updating UI with room:', room);

    if (!room) return;

    const currentUserId = BattleshipState.getUserId();
    
    // Determine which player is me
    const isPlayer1 = room.player1?.userId === currentUserId;
    const myPlayer = isPlayer1 ? room.player1 : room.player2;
    const opponentPlayer = isPlayer1 ? room.player2 : room.player1;

    // Update player 1 (me)
    const player1Name = document.getElementById('lobbyPlayer1Name');
    const player1Status = document.getElementById('lobbyPlayer1Status');
    const player1Img = document.getElementById('lobbyCharacter1');

    if (player1Name && myPlayer) {
        // Use guestDisplayName if guest, otherwise username
        const displayName = myPlayer.guestDisplayName || myPlayer.username || myPlayer.userId || 'You';
        player1Name.textContent = displayName;
    }

    if (player1Status && myPlayer) {
        if (myPlayer.ready) {
            player1Status.textContent = '✓ Sẵn sàng';
            player1Status.className = 'player-status-text status-ready';
        } else {
            player1Status.textContent = 'Đang chờ...';
            player1Status.className = 'player-status-text status-waiting';
        }
    }

    // Update player 2 (opponent)
    const player2Name = document.getElementById('lobbyPlayer2Name');
    const player2Status = document.getElementById('lobbyPlayer2Status');
    const player2Img = document.getElementById('lobbyCharacter2');

    if (opponentPlayer) {
        if (player2Name) {
            // Use guestDisplayName if guest, otherwise username
            const displayName = opponentPlayer.guestDisplayName || opponentPlayer.username || opponentPlayer.userId || 'Opponent';
            player2Name.textContent = displayName;
        }

        if (player2Status) {
            if (opponentPlayer.ready) {
                player2Status.textContent = '✓ Sẵn sàng';
                player2Status.className = 'player-status-text status-ready';
            } else {
                player2Status.textContent = 'Đang chờ...';
                player2Status.className = 'player-status-text status-waiting';
            }
        }

        if (player2Img) {
            player2Img.src = LOBBY_CHARACTERS[0].image; // Default character
            player2Img.classList.remove('portrait-waiting');
        }
    } else {
        // No opponent yet
        if (player2Name) {
            player2Name.textContent = 'Đang chờ đối thủ...';
        }

        if (player2Status) {
            player2Status.textContent = '-';
            player2Status.className = 'player-status-text status-empty';
        }

        if (player2Img) {
            player2Img.src = 'images/logo.png';
            player2Img.classList.add('portrait-waiting');
        }
    }

    // Start timer if both players present
    if (room.player1 && room.player2 && !lobbyTimerInterval) {
        startLobbyTimer(60);
    }
}

function updatePlayerReadyStatus(data) {
    const currentUserId = BattleshipState.getUserId();
    
    // Update status based on who sent ready
    if (data.userId === currentUserId) {
        // I'm ready
        const player1Status = document.getElementById('lobbyPlayer1Status');
        if (player1Status) {
            player1Status.textContent = '✓ Sẵn sàng';
            player1Status.className = 'player-status-text status-ready';
        }
    } else {
        // Opponent is ready
        const player2Status = document.getElementById('lobbyPlayer2Status');
        if (player2Status) {
            player2Status.textContent = '✓ Sẵn sàng';
            player2Status.className = 'player-status-text status-ready';
        }
        SocketShared.showNotification('Đối thủ đã sẵn sàng!', 'info');
    }
}

// CRITICAL: Ready button handler - triggers transition to game
function handleReady(socket, btn) {
    if (isReady) {
        SocketShared.showNotification('Bạn đã sẵn sàng rồi!', 'warning');
        return;
    }

    // Check if opponent present
    if (!currentRoom || !currentRoom.player2) {
        SocketShared.showNotification('Đang chờ đối thủ tham gia...', 'warning');
        return;
    }

    console.log('[Lobby] Ready button clicked - transitioning to game');
    
    // Mark as ready
    isReady = true;

    // Update button
    btn.disabled = true;
    btn.style.opacity = '0.6';
    btn.style.cursor = 'not-allowed';
    const btnText = btn.querySelector('.ready-text');
    if (btnText) btnText.textContent = 'ĐÃ SẴN SÀNG';

    // Update my status to ready
    const player1Status = document.getElementById('lobbyPlayer1Status');
    if (player1Status) {
        player1Status.textContent = '✓ Sẵn sàng';
        player1Status.className = 'player-status-text status-ready';
    }

    SocketShared.showNotification('Đang chờ đối thủ sẵn sàng...', 'info');
    
    // Emit a custom event to server to mark player as ready in lobby
    socket.emit('lobby:playerReady', {
        roomCode: BattleshipState.getRoomCode()
    });
}

function handleLeave(socket) {
    console.log('[Lobby] Emitting leave event');
    
    // Stop timer
    stopLobbyTimer();

    // Emit leave event
    socket.emit('room:leave', {
        roomCode: BattleshipState.getRoomCode()
    });

    // Clear room state
    BattleshipState.clearRoomState();

    // Redirect to hub
    SocketShared.showNotification('Đã rời phòng', 'info');
    setTimeout(() => {
        window.location.href = '/hub';
    }, 500);
}

function startLobbyTimer(seconds) {
    let timeLeft = seconds;
    const timerEl = document.getElementById('lobbyTimer');

    if (timerEl) {
        timerEl.textContent = timeLeft;
    }

    lobbyTimerInterval = setInterval(() => {
        timeLeft--;
        
        if (timerEl) {
            timerEl.textContent = timeLeft;
        }

        if (timeLeft <= 0) {
            stopLobbyTimer();
            SocketShared.showNotification('Hết thời gian chờ!', 'warning');
        }
    }, 1000);
}

function stopLobbyTimer() {
    if (lobbyTimerInterval) {
        clearInterval(lobbyTimerInterval);
        lobbyTimerInterval = null;
    }
}

// Character selector (UI-only cosmetic, no backend persistence)
function initCharacterSelector() {
    // Random character on load
    selectedCharacterIndex = Math.floor(Math.random() * LOBBY_CHARACTERS.length);
    updateCharacterPreview();
}

function updateCharacterPreview() {
    const character = LOBBY_CHARACTERS[selectedCharacterIndex];
    const characterImg = document.getElementById('lobbyCharacter1');
    const thumbs = document.querySelectorAll('.selector-thumb');

    if (characterImg) {
        characterImg.src = character.image;
        characterImg.style.opacity = '0';
        setTimeout(() => {
            characterImg.style.opacity = '1';
        }, 100);
    }

    thumbs.forEach((thumb, index) => {
        if (index === selectedCharacterIndex) {
            thumb.classList.add('selector-thumb-active');
        } else {
            thumb.classList.remove('selector-thumb-active');
        }
    });
}

console.log('[Lobby] Script loaded');
