// Chat functionality

let typingTimeout = null;

document.addEventListener('DOMContentLoaded', () => {
    const chatInput = document.getElementById('chatInput');
    const sendChatBtn = document.getElementById('sendChatBtn');

    if (chatInput && sendChatBtn) {
        // Send message on button click
        sendChatBtn.addEventListener('click', () => {
            sendMessage();
        });

        // Send message on Enter key
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        // Typing indicator
        chatInput.addEventListener('input', () => {
            if (!socket || !currentRoomId) return;

            sendTypingIndicator();

            // Clear previous timeout
            if (typingTimeout) {
                clearTimeout(typingTimeout);
            }

            // Hide typing indicator after 2 seconds of no input
            typingTimeout = setTimeout(() => {
                hideTypingIndicator();
            }, 2000);
        });
    }
});

function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();

    if (!message) return;

    if (!socket || !currentRoomId) {
        showNotification('Chưa kết nối đến phòng', 'error');
        return;
    }

    sendChatMessage(message);
    chatInput.value = '';
}

function addChatMessage(data) {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;

    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message';
    
    const isOwnMessage = data.userId === currentUserId;
    messageDiv.classList.add(isOwnMessage ? 'own' : 'other');

    const time = new Date(data.timestamp).toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit'
    });

    messageDiv.innerHTML = `
        ${!isOwnMessage ? `<div class="username">${data.username}</div>` : ''}
        <div class="text">${escapeHtml(data.message)}</div>
        <div class="time">${time}</div>
    `;

    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator(username) {
    const indicator = document.getElementById('typingIndicator');
    if (!indicator) return;

    indicator.textContent = `${username} đang nhập...`;
    indicator.style.display = 'block';

    setTimeout(() => {
        hideTypingIndicator();
    }, 3000);
}

function hideTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (!indicator) return;
    indicator.style.display = 'none';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

